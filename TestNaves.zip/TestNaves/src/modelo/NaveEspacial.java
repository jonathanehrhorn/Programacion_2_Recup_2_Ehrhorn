package modelo;

import java.io.Serializable;
import servicio.CSVSerializable;

public class NaveEspacial implements Comparable<NaveEspacial>, CSVSerializable, Serializable {
    private static final long SerialVersionUID = 1L;
    private int id;
    private String nombre;
    private Categoria categoria;
    private int capacidad;

    public NaveEspacial(int id, String nombre, Categoria categoria, int capacidad) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.capacidad = capacidad;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public static long getSerialVersionUID() {
        return SerialVersionUID;
    }
    
    @Override
    public String toString() {
        return "NaveEspacial{" + "id=" + id + ", nombre=" + nombre + ", categoria=" + categoria + ", capacidad=" + capacidad + '}';
    }

    @Override
    public int compareTo(NaveEspacial n) {
        return Integer.compare(id, n.id);
    }

    @Override
    public String toCSV() {
        return String.format("%d,%s,%s,%d", id, nombre, categoria, capacidad);
    }    
    
    public static NaveEspacial fromCSV(String naveEspacialCSV) {
        
        String[] valores = naveEspacialCSV.split(",");
        return new NaveEspacial(Integer.parseInt(valores[0]), valores[1], Categoria.valueOf(valores[2]), Integer.parseInt(valores[3]));
    }    

}
