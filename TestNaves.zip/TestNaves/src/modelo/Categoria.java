package modelo;

public enum Categoria {
    CIENTIFICA,
    TRANSPORTE,
    MILITAR
}
