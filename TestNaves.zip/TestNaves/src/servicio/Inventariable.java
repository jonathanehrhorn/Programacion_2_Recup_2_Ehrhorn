package servicio;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/*
o Agregar, eliminar y listar elementos.
o Ordenar elementos: se debe poder ordenar por orden natural o utilizando un Comparator. 
Por ejemplo, un comparador por capacidad de tripulación.
o Filtrar elementos: según un criterio proporcionado mediante un Predicate. 
Por ejemplo, filtrar todas las naves del tipo EXPLORACION.
o Transformar elementos: se debe permitir transformar los datos mediante un Function. 
Por ejemplo, cambiar el tipo de todas las naves a MILITAR.
o Guardar y cargar elementos: debe permitir:
  ▪ Serialización en un archivo binario.
  ▪ Guardar en un archivo CSV.
  ▪ Cargar desde un archivo CSV usando una función fromCSV.
*/

public interface Inventariable <T extends CSVSerializable> {

    void agregar(T item);
    T obtener(int indice);
    void eliminar(int indice);
    List<T> filtrar(Predicate<T> criterio);
    void ordenar();
    void ordenar(Comparator<T> comparador);
    void guardarEnArchivo(String path);
    void cargarDesdeArchivo(String path);
    void guardarEnCSV(String path);
    void cargarDesdeCSV(String path, Function<String, T> funcion);
    void paraCadaElemento(Consumer<T> accion);

}
