package testnaves;

import config.AppConstants;
import modelo.Categoria;
import modelo.NaveEspacial;
import servicio.Inventario;

public class TestNaves {

    public static void main(String[] args) {
        try {
            // Crear un inventario de naves espaciales
            Inventario<NaveEspacial> inventarioNaves = new Inventario<>(); 
            
            /*
            inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", "Exploración", Categoria.CIENTIFICA)); 
            inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", "Carga y Transporte", Categoria.TRANSPORTE)); 
            inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", "Combate Espacial", Categoria.MILITAR)); 
            inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", "Combate y Reconocimiento", Categoria.MILITAR)); 
            inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", "Exploración Lejana", Categoria.CIENTIFICA));
            */

            inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", Categoria.CIENTIFICA, 1500)); 
            inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", Categoria.TRANSPORTE, 100)); 
            inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", Categoria.MILITAR, 2)); 
            inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", Categoria.MILITAR, 2)); 
            inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", Categoria.CIENTIFICA, 200));
            
            // Mostrar todas las naves en el inventario 
            System.out.println("Inventario de naves espaciales:");
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

            // Filtrar naves por categoria MILITAR 
            System.out.println("\nNaves de la categoria MILITAR:");
            inventarioNaves.filtrar(n -> n.getCategoria().equals(Categoria.MILITAR))
                    .forEach(nave -> System.out.println(nave));

            // Filtrar naves cuyo nombre contiene "Falcon" 
            System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
            inventarioNaves.filtrar(n -> n.getNombre().contains("Falcon"))
            .forEach(nave -> System.out.println(nave));

            // Ordenar naves de manera natural (por id) 
            System.out.println("\nNaves ordenadas de manera natural (por id):");
            inventarioNaves.ordenar();
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));
            
            // Ordenar naves por nombre utilizando un Comparator 
            System.out.println("\nNaves ordenadas por nombre:");
            inventarioNaves.ordenar((n1, n2) -> n1.getNombre().compareTo(n2.getNombre()));
            inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));
            
            // Guardar el inventario en un archivo binario 
            inventarioNaves.guardarEnArchivo(AppConstants.SERIAL);
            
            // Cargar el inventario desde el archivo binario
            Inventario<NaveEspacial> inventarioCargado = new Inventario<>(); 

            inventarioCargado.cargarDesdeArchivo(AppConstants.SERIAL); 

            System.out.println("\nNaves cargadas desde archivo binario:");

            inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));
            
            // Guardar el inventario en un archivo CSV 
            inventarioNaves.guardarEnCSV(AppConstants.CSV);
            
            // Cargar el inventario desde el archivo CSV 
            inventarioCargado.cargarDesdeCSV(AppConstants.CSV, linea -> NaveEspacial.fromCSV(linea)); 
            
            System.out.println("\nNaves cargadas desde archivo CSV:");
            inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));
            } catch (RuntimeException e) { 
                System.err.println("Error: " + e.getMessage());
            }
    }
}
