package config;

public class AppConstants {

    public static final String PATH_ARCHIVOS = "src/data/";
    public static final String SERIAL = PATH_ARCHIVOS + "naves.dat";
    public static final String CSV = PATH_ARCHIVOS + "naves.csv";

}
